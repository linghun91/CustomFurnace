package cn.i7mc.customfurnace.managers;

import cn.i7mc.customfurnace.CustomFurnace;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.black_ixx.playerpoints.PlayerPoints;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyManager {
    private final CustomFurnace plugin;
    private boolean vaultEnabled = false;
    private boolean pointsEnabled = false;
    private Economy economy = null;
    private PlayerPointsAPI pointsAPI = null;

    public EconomyManager(CustomFurnace plugin) {
        this.plugin = plugin;
        boolean vaultSuccess = this.setupEconomy();
        boolean pointsSuccess = this.setupPlayerPoints();
        Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + "经济系统初始化状态: " + (vaultSuccess ? String.valueOf(ChatColor.GREEN) + "Vault=成功" : String.valueOf(ChatColor.RED) + "Vault=失败") + String.valueOf(ChatColor.GREEN) + ", " + (pointsSuccess ? String.valueOf(ChatColor.GREEN) + "PlayerPoints=成功" : String.valueOf(ChatColor.RED) + "PlayerPoints=失败"));
    }

    private boolean setupEconomy() {
        if (!this.plugin.getConfigManager().getConfig().getBoolean("economy.use-vault", true)) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "金币经济系统已禁用");
            return false;
        }
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "未找到Vault插件，金币经济系统将不可用");
            this.vaultEnabled = false;
            return false;
        }
        Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + "Vault插件已找到，尝试获取经济服务...");
        RegisteredServiceProvider rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "未找到经济服务提供者，金币经济系统将不可用");
            this.vaultEnabled = false;
            return false;
        }
        this.economy = (Economy)rsp.getProvider();
        boolean bl = this.vaultEnabled = this.economy != null;
        if (this.vaultEnabled) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + "成功连接到Vault经济系统: " + this.economy.getName());
        } else {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "无法连接到Vault经济系统");
        }
        return this.vaultEnabled;
    }

    private boolean setupPlayerPoints() {
        if (!this.plugin.getConfigManager().getConfig().getBoolean("economy.use-points", true)) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "点券系统已禁用");
            return false;
        }
        PlayerPoints pointsPlugin = (PlayerPoints)Bukkit.getPluginManager().getPlugin("PlayerPoints");
        if (pointsPlugin == null) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "未找到PlayerPoints插件，点券系统将不可用");
            this.pointsEnabled = false;
            return false;
        }
        Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + "PlayerPoints插件已找到，尝试获取API...");
        try {
            this.pointsAPI = pointsPlugin.getAPI();
            boolean bl = this.pointsEnabled = this.pointsAPI != null;
            if (this.pointsEnabled) {
                Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + "成功连接到PlayerPoints点券系统");
            } else {
                Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "无法连接到PlayerPoints点券系统");
            }
        } catch (Exception e) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + "连接PlayerPoints API时发生错误: " + e.getMessage());
            e.printStackTrace();
            this.pointsEnabled = false;
        }
        return this.pointsEnabled;
    }

    public boolean isVaultEnabled() {
        return this.vaultEnabled && this.economy != null;
    }

    public boolean isPointsEnabled() {
        return this.pointsEnabled && this.pointsAPI != null;
    }

    public boolean hasEnoughVaultBalance(Player player, double amount) {
        if (!this.isVaultEnabled()) {
            this.plugin.getLogger().warning("尝试检查金币余额，但Vault经济系统未启用");
            return false;
        }
        boolean hasEnough = this.economy.has((OfflinePlayer)player, amount);
        return hasEnough;
    }

    public boolean hasEnoughPoints(Player player, int amount) {
        if (!this.isPointsEnabled()) {
            return false;
        }
        int balance = this.pointsAPI.look(player.getUniqueId());
        boolean hasEnough = balance >= amount;
        return hasEnough;
    }

    public boolean withdrawVault(Player player, double amount) {
        if (!this.isVaultEnabled()) {
            this.plugin.getLogger().warning("尝试扣除金币，但Vault经济系统未启用");
            return false;
        }
        if (!this.hasEnoughVaultBalance(player, amount)) {
            return false;
        }
        double before = this.economy.getBalance((OfflinePlayer)player);
        EconomyResponse response = this.economy.withdrawPlayer((OfflinePlayer)player, amount);
        double after = this.economy.getBalance((OfflinePlayer)player);
        return response.transactionSuccess();
    }

    public boolean withdrawPoints(Player player, int amount) {
        if (!this.isPointsEnabled()) {
            return false;
        }
        if (!this.hasEnoughPoints(player, amount)) {
            return false;
        }
        int before = this.pointsAPI.look(player.getUniqueId());
        boolean success = this.pointsAPI.take(player.getUniqueId(), amount);
        int after = this.pointsAPI.look(player.getUniqueId());
        return success;
    }

    public double getVaultBalance(Player player) {
        if (!this.isVaultEnabled()) {
            return 0.0;
        }
        return this.economy.getBalance((OfflinePlayer)player);
    }

    public int getPointsBalance(Player player) {
        if (!this.isPointsEnabled()) {
            return 0;
        }
        return this.pointsAPI.look(player.getUniqueId());
    }
}

