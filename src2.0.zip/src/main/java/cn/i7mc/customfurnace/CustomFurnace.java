package cn.i7mc.customfurnace;

import cn.i7mc.customfurnace.commands.FurnaceCommand;
import cn.i7mc.customfurnace.listeners.ExplosionListener;
import cn.i7mc.customfurnace.listeners.FurnaceListener;
import cn.i7mc.customfurnace.listeners.InventoryListener;
import cn.i7mc.customfurnace.managers.ConfigManager;
import cn.i7mc.customfurnace.managers.DataManager;
import cn.i7mc.customfurnace.managers.EconomyManager;
import cn.i7mc.customfurnace.managers.FurnaceManager;
import cn.i7mc.customfurnace.managers.LangManager;
import cn.i7mc.customfurnace.utils.MessageUtil;
import cn.i7mc.customfurnace.utils.TextDisplayUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class CustomFurnace
extends JavaPlugin {
    private ConfigManager configManager;
    private LangManager langManager;
    private FurnaceManager furnaceManager;
    private DataManager dataManager;
    private MessageUtil messageUtil;
    private EconomyManager economyManager;
    private TextDisplayUtil textDisplayUtil;
    private FurnaceListener furnaceListener;
    private InventoryListener inventoryListener;

    public void onEnable() {
        this.configManager = new ConfigManager(this);
        this.langManager = new LangManager(this.configManager);
        this.messageUtil = new MessageUtil(this.langManager);
        this.textDisplayUtil = new TextDisplayUtil(this);
        this.furnaceManager = new FurnaceManager(this, this.configManager, this.langManager);
        this.dataManager = new DataManager(this);
        this.economyManager = new EconomyManager(this);
        this.registerListeners();
        this.registerCommands();
        this.dataManager.applyAllFurnaces();
        Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.GREEN) + this.langManager.getRawMessage("plugin.enable"));
        Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.AQUA) + "QQ2680517068专属的定制插件");
        if (this.configManager.isProgressBarEnabled()) {
            int updateInterval = this.configManager.getProgressBarUpdateInterval();
            this.getServer().getScheduler().runTaskTimer((Plugin)this, () -> this.dataManager.updateFurnaceProgressBars(), 20L, (long)updateInterval);
        }
    }

    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();

        // 初始化并注册熔炉监听器
        furnaceListener = new FurnaceListener(this);
        pm.registerEvents(furnaceListener, this);

        // 初始化并注册物品栏监听器
        inventoryListener = new InventoryListener(this);
        pm.registerEvents(inventoryListener, this);
    }

    /**
     * 注册命令
     */
    private void registerCommands() {
        FurnaceCommand furnaceCommand = new FurnaceCommand(this);
        this.getCommand("furnace").setExecutor((CommandExecutor)furnaceCommand);
        this.getCommand("furnace").setTabCompleter((TabCompleter)furnaceCommand);
    }

    public void onDisable() {
        this.getServer().getScheduler().cancelTasks((Plugin)this);
        if (this.dataManager != null && this.configManager.isArmorstandHologramEnabled()) {
            this.getServer().getWorlds().forEach(world -> world.getEntities().stream().filter(entity -> entity instanceof TextDisplay).map(entity -> (TextDisplay)entity).filter(textDisplay -> textDisplay.getText() != null).forEach(Entity::remove));
        }
        if (this.dataManager != null) {
            this.dataManager.shutdown();
        }
        if (this.configManager != null) {
            this.configManager.saveConfigs();
        }
        if (this.langManager != null) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.DARK_AQUA) + "[CustomFurnace] " + String.valueOf(ChatColor.RED) + this.langManager.getRawMessage("plugin.disable"));
        }
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public LangManager getLangManager() {
        return this.langManager;
    }

    public FurnaceManager getFurnaceManager() {
        return this.furnaceManager;
    }

    public DataManager getDataManager() {
        return this.dataManager;
    }

    public MessageUtil getMessageUtil() {
        return this.messageUtil;
    }

    public EconomyManager getEconomyManager() {
        return this.economyManager;
    }

    public InventoryListener getInventoryListener() {
        return this.inventoryListener;
    }

    public TextDisplayUtil getTextDisplayUtil() {
        return this.textDisplayUtil;
    }

    /**
     * 重写配置重载方法，确保所有组件正确重载
     */
    @Override
    public void reloadConfig() {
        // 调用父类重载配置
        super.reloadConfig();
        
        // 在服务器启动后才执行额外的重载逻辑
        if (this.configManager != null && this.isEnabled()) {
            // 重载语言管理器
            if (this.langManager != null) {
                this.langManager.reload();
            }
            
            // 刷新所有现有全息图的显示设置
            if (this.textDisplayUtil != null) {
                this.textDisplayUtil.refreshAllHologramSettings();
            }
        }
    }
}

